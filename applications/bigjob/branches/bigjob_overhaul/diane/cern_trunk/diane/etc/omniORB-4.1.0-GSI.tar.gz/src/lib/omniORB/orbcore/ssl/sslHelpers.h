//------------------- sslHelpers.h ------------------------
// -*- Mode:c++ -*-
// $Id: sslHelpers.h,v 1.1 2006/03/14 12:59:21 nsantos Exp $
//
#ifndef SSL_HELPERS_H
#define SSL_HELPERS_H

#include <omniORB4/CORBA.h>

#include <openssl/ssl.h>
#include <openssl/evp.h>
#include <openssl/err.h>

#include <string>

void sslPrintErrors();
int sslHandleError(SSL *ssl, int ret);

int certVerifyCallback(int ok, X509_STORE_CTX *store);
int certVerifyCallbackAllowProxy(int ok, X509_STORE_CTX *store);
int checkIssuerCallback(X509_STORE_CTX *ctx, X509 *cert, X509 *issuer);
int isProxyCert(X509 *cert);
int isProxyOf(X509 *child, X509 *parent);

std::string getCertSubjectName(X509 *cert, bool traditional = false);

std::string sessionToPrintable(unsigned char *sessionID, unsigned int len);

#endif //SSL_HELPERS_H
