//------------------- sslHelpers.cc ------------------------
// callbacks for SSL and some helper routines

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <ssl/sslHelpers.h>
#include <openssl/x509v3.h>
#include <openssl/evp.h>

static int debug = 1;

void
sslPrintErrors ()
{
  // see "man BIO_s_mem"

  omniORB::logger log;
  log << "SSL error queue: ";

  char buff[201];
  BIO *mem = BIO_new (BIO_s_mem ());
  ERR_print_errors (mem);
  while (!BIO_eof (mem))
    {
      BIO_gets (mem, buff, 200);
      omniORB::logs (1, buff);
    }
  BIO_free (mem);
}


/// Callback when certificates are checked
/** This callback is given to SSL_CTX_set_verify and prints out error
     messages when certificate chains are verified.
  */
int
certVerifyCallback (int ok, X509_STORE_CTX * store)
{
  char buff[256];

  if (!ok && omniORB::trace (10))
    {
      omniORB::logger log;
      X509 *cert = X509_STORE_CTX_get_current_cert (store);
      int depth = X509_STORE_CTX_get_error_depth (store);
      int err = X509_STORE_CTX_get_error (store);
      log << "Client certificate error at depth: " << depth << " error " <<
	err;
      X509_NAME_oneline (X509_get_issuer_name (cert), buff, 256);
      log << "   issuer = " << buff << "\n";
      X509_NAME_oneline (X509_get_subject_name (cert), buff, 256);
      log << "   subject = " << buff << "\n";
      log << "   error   = " << X509_verify_cert_error_string (err) << "\n";

    }

  return ok;
}


/// Callback when certificates are checked, allows proxy certs
/** This callback is given to SSL_CTX_set_verify to allow grid proxy
     certificates to be used.
     In contrast to the Globus solution it does not rely on a
     proprietary mechanism to build the certificate chains but leaves
     this to openssl itself allowing us to profit from the several
     bug-fixes in the 0.9.6, 0.9.7 and 0.9.8 releases. This routine
     only overrides the certificate verification in 2 cases where a user
     certificate is used to create another proxy certificate:
     X509_V_ERR_INVALID_CA and X509_V_ERR_INVALID_PURPOSE
     In both cases it is carefully checked that the certificate signed
     is only a proxy certificate.
     This callback is also needed for openssl 0.9.8 because most admins will
     have proxy certificates disabled in the openssl configuration, anyway.
     This version of the callback works with 0.9.6a-0.9.8a.
     The idea of the routine is taken from the example in the 0.9.7
     man-page of SSL_CTX_set_verify.
*/
int
certVerifyCallbackAllowProxy (int ok, X509_STORE_CTX * store)
{
  omniORB::logs (10, "certVerifyCallbackAllowProxy called:");

#if OPENSSL_VERSION_NUMBER < 0x00907000L
  store->check_issued = checkIssuerCallback;
#endif

  char buff[256];

  // See man SSL_CTX_set_verify
  if (!ok)
    {
      X509 *cert = X509_STORE_CTX_get_current_cert (store);
      int depth = X509_STORE_CTX_get_error_depth (store);
      int err = X509_STORE_CTX_get_error (store);

      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "Possible certificate error at depth: " << depth << " error "
	    << err << "\n";
	  X509_NAME_oneline (X509_get_issuer_name (cert), buff, 256);
	  log << "   issuer = " << buff << "\n";
	  X509_NAME_oneline (X509_get_subject_name (cert), buff, 256);
	  log << "   subject = " << buff << "\n";
	  log << "   error   = " << X509_verify_cert_error_string (err) <<
	    "\n";
	}

      bool isProxy = isProxyCert (cert);

// In 0.9.6 we cannot override the issuer check, so we need
// to check whether we have a proxy cert at hand an ignore all
// the resulting errors
#if OPENSSL_VERSION_NUMBER < 0x00907000L
      if (isProxy && err == X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (1,
			 "Ignoring X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY for proxy cert\n");
	  return 1;
	}
      if (isProxy && err == X509_V_ERR_CERT_UNTRUSTED)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (1,
			 "Ignoring X509_V_ERR_CERT_UNTRUSTED for proxy cert\n");
	  return 1;
	}
      if (isProxy && err == X509_V_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (1,
			 "Ignoring X509_V_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE for proxy cert\n");
	  return 1;
	}
#endif

      bool isProxyDelegator = false;
      STACK_OF (X509) * chain = X509_STORE_CTX_get_chain (store);
      if (chain && sk_num (chain))
	{
	  if (omniORB::trace (10))
	    {
	      omniORB::logger log;
	      log << "Certificate chain length: " << sk_num (chain);
	    }
	  if (depth > 0 && depth <= sk_num (chain))
	    {
	      isProxyDelegator =
		isProxyOf ((X509 *) sk_value (chain, depth - 1), cert);
	    }
	}
      // Handle proxy cerificates
      if (isProxyDelegator && err == X509_V_ERR_INVALID_CA)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (10,
			 "Ignoring X509_V_ERR_INVALID_CA for proxy cert delegator\n");
	  return 1;
	}

      if (isProxyDelegator && err == X509_V_ERR_INVALID_PURPOSE)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (10,
			 "Ignoring X509_V_ERR_INVALID_PURPOSE for proxy cert delegator\n");
	  return 1;
	}
      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "isProxy: " << isProxy << "err: " << err << "\n";
	}
      if (isProxy && err == X509_V_ERR_UNABLE_TO_GET_CRL)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (10,
			 "Ignoring X509_V_ERR_UNABLE_TO_GET_CRL in proxy cert\n");
	  return 1;
	}
      //usercert (EE) is not found in the CApath 	      
      if (isProxy && err == X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY)
	{
	  X509_STORE_CTX_set_error (store, X509_V_OK);
	  omniORB::logs (10,
			 "Ignoring X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY in proxy cert\n");
	  return 1;
	}
      //allow ssl servers to use proxy certificates
      if (isProxy && err == X509_V_ERR_INVALID_PURPOSE)
        {
          X509_STORE_CTX_set_error (store, X509_V_OK);
          omniORB::logs (10,
                         "Ignoring X509_V_ERR_INVALID_PURPOSE in proxy cert\n");
          return 1;
        }
    }
  if (omniORB::trace (10))
    {
      omniORB::logger log;
      log << "  Callback returns: " << ok << "\n";
    }

  return ok;
}

/** This is a modified version of the issuer check routine
     which overrrides the error that a user certificate is used to sign
     a proxy certificate although it does not have this capability.
     All other checks are done by openssl's standard X509_check_issued
     routine which allows us to profit from any security fix being done
     in openssl.
     This routine is enabled by overriding the
     ctx->cert_store->check_issued function pointer of the certificte
     store of the SSL context in 0.9.7 and above. In 0.9.6 we need to do 
     this in the verify routine itself.
     The idea of the code is stolen from openssl's own checking
     routine in x509_vfy.c.
     Returns 1 for OK and 0 for error
*/
int
checkIssuerCallback (X509_STORE_CTX * ctx, X509 * cert, X509 * issuer)
{
  omniORB::logs (10, "checkIssuerCallback called:");
  int ret = X509_check_issued (issuer, cert);
  if (omniORB::trace (15))
    {
      omniORB::logger log;
      char buff[256];
      log << "   Checking:\n Cert Subject: ";
      X509_NAME_oneline (X509_get_subject_name (cert), buff, 256);
      log << buff << "\n";
      log << "Cert issuer: ";
      X509_NAME_oneline (X509_get_issuer_name (cert), buff, 256);
      log << buff << "\n";
      log << "Parent Subject: ";
      X509_NAME_oneline (X509_get_subject_name (issuer), buff, 256);
      log << buff << "\n";
      log << "Parent issuer: ";
      X509_NAME_oneline (X509_get_issuer_name (issuer), buff, 256);
      log << buff << "\n";
      log << "   OpenSSL Status Code: " << X509_verify_cert_error_string (ret)
	<< ": " << ret << "\n";
    }
  switch (ret)
    {
    case X509_V_OK:
      return 1;			// OK

    case X509_V_ERR_KEYUSAGE_NO_CERTSIGN:
      // Ignore problem with key usage not including cert-signing for  proxy certs 
      if (isProxyOf (cert, issuer))
	{
	  omniORB::logs (10, "Ignoring X509_V_ERR_KEYUSAGE_NO_CERTSIGN \n");
	  // Return directly, no need to override our decision in CB
	  return 1;		// OK
	}
#if OPENSSL_VERSION_NUMBER < 0x00907000L
    case X509_V_ERR_SUBJECT_ISSUER_MISMATCH:
      // Ignore problem with key usage not including cert-signing for   proxy certs 
      if (isProxyOf (cert, issuer))
	{
	  omniORB::logs (10, "Ignoring X509_V_ERR_SUBJECT_ISSUER_MISMATCH\n");
	  // Return directly, no need to override our decision in CB
	  return 1;		// OK
	}
#endif
    }

#if OPENSSL_VERSION_NUMBER >= 0x00908000L
  // If we haven't asked for issuer errors don't set ctx
  if (!(ctx->param->flags & X509_V_FLAG_CB_ISSUER_CHECK))
    return 0;
#else
  // If we haven't asked for issuer errors don't set ctx
  if (!(ctx->flags & X509_V_FLAG_CB_ISSUER_CHECK))
    return 0;
#endif

  omniORB::logs (10, "  returning via verify_cb\n");

  // Allows our callback to override the decision
  ctx->error = ret;
  ctx->current_cert = cert;
  ctx->current_issuer = issuer;
  return ctx->verify_cb (0, ctx);
}


/** Routine which checks whether cert is a proxy certificate
     The check for a proxy certificate is done by verifying that
     the cert and its issuer share the same common name apart from
     an additional proxying in the certificate itself.
*/
int
isProxyCert (X509 * cert)
{
  X509_NAME *subject;
  X509_NAME *issuer;

  subject = X509_get_subject_name (cert);
  if (!subject)
    return 0;

  issuer = X509_get_issuer_name (cert);
  if (!issuer)
    return 0;

  std::string realName;
  int proxyLevel = 0;

  std::string issuerRealName;
  int issuerProxyLevel = 0;

  int pos = -1;
  while ((pos =
	  X509_NAME_get_index_by_NID (subject, NID_commonName, pos)) > -1)
    {
      X509_NAME_ENTRY *e = X509_NAME_get_entry (subject, pos);
      if (!e)
	break;
      std::string value;
      value =
	(const char *) (ASN1_STRING_data (X509_NAME_ENTRY_get_data (e)));
      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "Value: >" << value.c_str () << "<" << "\n";
	}
      if (value != "proxy" && value != "limited proxy" && !realName.size ())
	realName = value;
      if (value == "proxy" || value == "limited proxy")
	proxyLevel++;
    }

  pos = -1;
  while ((pos =
	  X509_NAME_get_index_by_NID (issuer, NID_commonName, pos)) > -1)
    {
      X509_NAME_ENTRY *e = X509_NAME_get_entry (issuer, pos);
      if (!e)
	break;
      std::string value;
      value =
	(const char *) (ASN1_STRING_data (X509_NAME_ENTRY_get_data (e)));
      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "Issuer Value: >" << value.c_str () << "<" << "\n";
	}
      if (value != "proxy" && value != "limited proxy"
	  && !issuerRealName.size ())
	issuerRealName = value;
      if (value == "proxy" || value == "limited proxy")
	issuerProxyLevel++;
    }
  if (omniORB::trace (10))
    {
      omniORB::logger log;
      log << "  Real name: >" << realName.
	c_str () << "< and Issuer real name: " << issuerRealName.
	c_str () << "\n";
      log << "  Proxy level: " << proxyLevel << " and " << issuerProxyLevel <<
	"\n";
    }
  if (proxyLevel == issuerProxyLevel + 1 && issuerRealName == realName)
    {
      omniORB::logs (10, " IS a proxy\n");
      return 1;
    }

  omniORB::logs (10, "NOT a proxy!\n");

  return 0;
}


/** Routine which checks whether the child-cert is a proxy of parent
     The check for a proxy certificate is done by verifying that
     the cert and its issuer share the same common name apart from
     an additional proxying in the certificate itself.
*/
int
isProxyOf (X509 * child, X509 * parent)
{
  omniORB::logs (10, "Entering isProxyOf\n");

  int childProxyLevel = 0;
  int parentProxyLevel = 0;
  std::string childRealName;
  std::string parentRealName;

  X509_NAME *childSubject = X509_get_subject_name (child);
  if (!childSubject)
    return 0;

  X509_NAME *parentSubject = X509_get_subject_name (parent);
  if (!parentSubject)
    return 0;

  int pos = -1;
  while ((pos =
	  X509_NAME_get_index_by_NID (childSubject, NID_commonName,
				      pos)) > -1)
    {
      X509_NAME_ENTRY *e = X509_NAME_get_entry (childSubject, pos);
      if (!e)
	break;
      std::string value;
      value =
	(const char *) (ASN1_STRING_data (X509_NAME_ENTRY_get_data (e)));
      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "Value: >" << value.c_str () << "<" << "\n";
	}
      if (value != "proxy" && value != "limited proxy")
	childRealName += value;
      if (value == "proxy" || value == "limited proxy")
	childProxyLevel++;
    }

  pos = -1;
  while ((pos =
	  X509_NAME_get_index_by_NID (parentSubject, NID_commonName,
				      pos)) > -1)
    {
      X509_NAME_ENTRY *e = X509_NAME_get_entry (parentSubject, pos);
      if (!e)
	break;
      std::string value;
      value =
	(const char *) (ASN1_STRING_data (X509_NAME_ENTRY_get_data (e)));
      if (omniORB::trace (10))
	{
	  omniORB::logger log;
	  log << "Value: >" << value.c_str () << "<" << "\n";
	}
      if (value != "proxy" && value != "limited proxy")
	parentRealName += value;
      if (value == "proxy" || value == "limited proxy")
	parentProxyLevel++;
    }
  if (omniORB::trace (10))
    {
      omniORB::logger log;
      log << "  Child real name: " << childRealName.
	c_str () << " and parent real name: " << parentRealName.
	c_str () << "\n";
      log << "  Proxy level: " << childProxyLevel << " and " <<
	parentProxyLevel << "\n";
    }
  if (childRealName == parentRealName
      && childProxyLevel == parentProxyLevel + 1)
    return 1;

  if (omniORB::trace (10))
    {
      omniORB::logger log;
      log << "Not a proxy cert\n";
    }

  return 0;
}


/** Returns the subject name of a certificate (presented by a client)
     for normal non-proxy certificates.
     If the certificate is in fact a proxy certificate, not the subject
     but the issuer is returned (which is the subject of the
     certificate of the original user).
*/
std::string getCertSubjectName (X509 * cert, bool traditional)
{
  if (!cert)
    return "";

  char buff[256];
  X509_NAME *subject;

  bool isProxy = isProxyCert (cert);
  if (isProxy)
    subject = X509_get_issuer_name (cert);
  else
    subject = X509_get_subject_name (cert);

  if (traditional)
    {
      X509_NAME_oneline (subject, buff, 255);
    }
  else
    {
      BIO *mem = BIO_new (BIO_s_mem ());
      X509_NAME_print_ex (mem, subject, 0, XN_FLAG_ONELINE);

      BIO_gets (mem, buff, 255);
      BIO_free (mem);
    }

  while (traditional && isProxy && strlen (buff) > 9)
    {
      if (!strcmp (buff + strlen (buff) - 9, "/CN=proxy"))
	buff[strlen (buff) - 9] = '\0';
      else
	break;
    }

  while (traditional && isProxy && strlen (buff) > 17)
    {
      if (!strcmp (buff + strlen (buff) - 17, "/CN=limited proxy"))
	buff[strlen (buff) - 17] = '\0';
      else
	break;
    }

  while (!traditional && isProxy && strlen (buff) > 12)
    {
      if (!strcmp (buff + strlen (buff) - 12, ", CN = proxy"))
	buff[strlen (buff) - 12] = '\0';
      else
	break;
    }

  while (!traditional && isProxy && strlen (buff) > 20)
    {
      if (!strcmp (buff + strlen (buff) - 20, ", CN = limited proxy"))
	buff[strlen (buff) - 20] = '\0';
      else
	break;
    }

  if (omniORB::trace (10))
    {
      omniORB::logger log;
      log << "Buff: >" << buff << "<\n";
    }

  return buff;
}
